/**
 * The source code of Burn Background Telegram bot
 *
 * With this bot you can remove background
 * from any picture. Enough of manual work, let the bot
 * do it for you
 *
 * Copyright (c) 2021-2022 Vyacheslav <slava021323@gmail.com>
 */
require('./src/bot');
